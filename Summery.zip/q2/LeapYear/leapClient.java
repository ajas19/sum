import java.rmi.*;
import java.rmi.Naming;
import java.util.Scanner;

class leapClient {

	public static void main(String[]args) {

		try {

			leapInterface obj = (leapInterface) Naming.lookup("xyz");
			Scanner sc = new Scanner(System.in);

			System.out.print("Enter the year : ");
			int year = sc.nextInt();

			System.out.println(obj.check(year));

		}

		catch(Exception e) {

			System.out.println("Error : " + e);

		}

	}
}