import java.rmi.*;
import java.rmi.Naming;

class leapServer {

	public static void main(String[]args) {

		try {

			leapImplementation obj = new leapImplementation();
			Naming.rebind("xyz", obj);
			System.out.println("Server is running...");

		}

		catch(Exception e) {

			System.out.println("Error : " + e);

		}

	}
}