import java.rmi.*;

interface leapInterface extends Remote {

	public String check(int x) throws RemoteException;
	
}