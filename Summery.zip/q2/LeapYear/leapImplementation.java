import java.rmi.*;
import java.rmi.server.*;

class leapImplementation extends UnicastRemoteObject implements leapInterface {

	public leapImplementation() throws RemoteException {
		super();
	}

	public String check(int x) throws RemoteException {

		if(x % 400 == 0 && x % 100 != 0 || x % 4 == 0) {
			return "\nThis Year is a Leap Year.";
		}
		else {
			return "\nThis Year is not a Leap Year.";
		}

	}

}
