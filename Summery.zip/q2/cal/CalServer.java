import java.rmi.*;
import java.rmi.Naming.*;

class CalServer {

	public static void main(String[] args) {
		
		try {
			CalImplimentation obj = new CalImplimentation();
			Naming.rebind("ABC", obj);
			System.out.println("Server is working.");
		}

		catch(Exception e) {
			System.out.println("Error : " + e);
		}

	}

}