import java.rmi.*;
import java.rmi.Naming.*;
import java.util.Scanner;

class CalClient {

	public static void main(String[] args) {
		
		try {
			Scanner scn = new Scanner(System.in);

			System.out.print("Enter the first number : ");
			int num1 = scn.nextInt();
			System.out.print("Enter the operator : ");
			char opr = scn.next().charAt(0);
			System.out.print("Enter the second number : ");
			int num2 = scn.nextInt();

			CalInterface OBJ = (CalInterface) Naming.lookup("ABC");

			if(opr == '+')
			{
				System.out.println("\n" + num1 + "+" + num2 + " = " + OBJ.sum(num1, num2));
			}
			else if(opr == '-')
			{
				System.out.println("\n" + num1 + "-" + num2 + " = " + OBJ.sub(num1, num2));
			}
			else if(opr == '*')
			{
				System.out.println("\n" + num1 + "*" + num2 + " = " + OBJ.mul(num1, num2));
			}
			else if(opr == '/')
			{
				System.out.println("\n" + num1 + "/" + num2 + " = " + OBJ.div(num1, num2));
			}
			else
			{
				System.out.println("\nInvalid Input.");
			}
		}

		catch(Exception e) {
			System.out.println("Error : " + e);
		}

	}

}