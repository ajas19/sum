#include <mpi.h>
#include <stdio.h>

int main() {

	MPI_Init(NULL, NULL);

	int length, width, area;

	int rank;
	MPI_Comm_rank(MPI_COMM_WORLD, &rank);

	int size;
	MPI_Comm_size(MPI_COMM_WORLD, &size);

	if(rank == 0) {
		printf("Enter the width : ");
		scanf("%d", &width);
		printf("Enter the length : ");
		scanf("%d", &length);

		MPI_Send(&width, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
		MPI_Send(&length, 1, MPI_INT, 1, 0, MPI_COMM_WORLD);
	}
	else if(rank == 1) {
		MPI_Recv(&width, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);
		MPI_Recv(&length, 1, MPI_INT, 0, 0, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

		area = width * length;

		MPI_Send(&area, 1, MPI_INT, 2, 1, MPI_COMM_WORLD);
	}
	else if(rank == 2) {
		MPI_Recv(&area, 1, MPI_INT, 1, 1, MPI_COMM_WORLD, MPI_STATUS_IGNORE);

		printf("\nArea is : %d\n\n", area);
	}

	MPI_Finalize();

}